<div align="center">
  <img src="assets/hexmora-mark.svg" alt="HEXMORA — SystemScope" width="520" />
  <h1>SystemScope</h1>
  <p><strong>A local-first desktop dashboard for understanding your system and storage.</strong></p>
  <p>
    <img alt="Version" src="https://img.shields.io/badge/version-1.0.0-D4AF37?style=for-the-badge" />
    <img alt="Python" src="https://img.shields.io/badge/Python-3.10%2B-3776AB?style=for-the-badge&logo=python&logoColor=white" />
    <img alt="Platform" src="https://img.shields.io/badge/platform-Linux%20%7C%20Windows%20%7C%20macOS-64748b?style=for-the-badge" />
    <img alt="License" src="https://img.shields.io/badge/license-MIT-14b8a6?style=for-the-badge" />
  </p>
  <p><em>Built with Python · PySide6 · psutil · Branded by HEXMORA</em></p>
</div>

---

## Overview

New to GitHub? Follow [`GITHUB_UPLOAD.md`](GITHUB_UPLOAD.md) for the first upload and release steps.


**SystemScope** is a desktop system and storage inspection tool with a live performance dashboard. It brings common system metrics, storage insights, file metadata, installed-software inventory, and selected file-security checks into one interface.

SystemScope is designed to be **local-first and read-only by default**. It does not delete or modify scanned files, and it does not send your scan data to a server.

## Features

| Area | What it provides |
|---|---|
| Live dashboard | CPU, memory, system-disk usage, network throughput, disk read/write throughput, and recent trend lines |
| Storage insights | File-type breakdown, largest files, and largest folders |
| File explorer | Scan a chosen folder, search/filter results, inspect metadata, and sort tables |
| Software inventory | Best-effort list of installed applications using available OS package sources |
| Security center | Explicit SHA-256 hashing and basic file-permission inspection |
| Reports | Export supported scan results to CSV and JSON |
| Interface | Dark graphite/navy styling with gold branding and cyan live telemetry |

## Screenshots

Screenshots are intentionally not fabricated. Add genuine screenshots from your own running build to `docs/screenshots/`, then embed them here. See [`docs/SCREENSHOTS.md`](docs/SCREENSHOTS.md) for the recommended capture list.

## Safety and privacy

- **Read-only scanning:** scanning does not delete or modify files.
- **No administrator/root requirement:** run as your normal user. Access is limited to files your account can read.
- **No automatic uploads or telemetry:** scan results remain on your machine unless you choose to export and share them.
- **No file-content inspection during metadata scans:** file contents are read only for an explicit SHA-256 hashing action.
- **Symlinks are skipped** during directory traversal by default.
- **Sensitive locations are excluded** by the scanner's default exclusion rules.
- **Not antivirus software:** SystemScope does not claim to detect or remove malware.

Review the source code and test the application in your own environment before relying on its output.

## Requirements

- Python **3.10 or newer**
- A desktop environment capable of running Qt applications
- Internet access for the first dependency installation

Runtime dependencies are listed in [`requirements.txt`](requirements.txt).

## Quick start

### Linux (Debian, Ubuntu, Kali, Arch)

Install Python and virtual-environment support using your distribution's package manager. On Debian/Ubuntu/Kali:

```bash
sudo apt update
sudo apt install python3 python3-venv python3-pip -y
```

On Arch Linux:

```bash
sudo pacman -Syu
sudo pacman -S python python-pip
```

Then, from the project directory:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python main.py
```

### Windows 10 / 11

Install Python 3.10+ from [python.org](https://www.python.org/downloads/) and enable **Add Python to PATH**. Open PowerShell in the project directory:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python main.py
```

If script execution is blocked in that PowerShell window, run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Then activate the environment again.

### macOS

Install Python 3.10+ from [python.org](https://www.python.org/downloads/) or Homebrew. In Terminal, from the project directory:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python main.py
```

## Build a standalone application

SystemScope uses PyInstaller. **PyInstaller is not a cross-compiler:** build on the operating system you want to target.

| Target | Run on | Command | Output archive |
|---|---|---|---|
| Linux | Linux | `bash scripts/build_linux.sh` | `release/SystemScope-linux-<architecture>.tar.gz` |
| Windows | Windows PowerShell | `./scripts/build_windows.ps1` | `release/SystemScope-windows-x64.zip` |
| macOS | macOS | `bash scripts/build_macos.sh` | `release/SystemScope-macos-<architecture>.zip` |

The Windows archive contains the complete PyInstaller application folder; do not distribute only the `.exe`. Linux compatibility depends on the build system and its system libraries. macOS builds are unsigned and not notarized by this project.

## Automated checks and builds

GitHub Actions workflows are included:

- **CI** runs the unit tests and Python syntax checks on Linux, Windows, and macOS.
- **Build** creates native application artifacts on supported GitHub-hosted runners. It can be started manually or by pushing a version tag.

To create a version tag after reviewing your changes:

```bash
git tag -a v1.0.0 -m "SystemScope 1.0.0"
git push origin v1.0.0
```

Open the repository's **Actions** tab to inspect workflow results and download build artifacts. When a `v*` tag is pushed, the workflow also creates a GitHub Release and attaches the three platform archives automatically. The GitHub-hosted macOS runner target is Apple Silicon; Arch Linux builds must be run on an Arch Linux machine.

## Tests

From the project root, activate your virtual environment and run:

```bash
python -m unittest discover -s tests -v
python -m compileall -q main.py core ui tests
```

The current unit tests cover basic folder metadata scanning and SHA-256 hashing. They do **not** replace GUI testing on each supported operating system.

## Project structure

```text
SystemScope/
├── .github/                 # CI, build automation, issue and PR templates
├── assets/                  # HEXMORA branding assets
├── core/                    # System information, scanning, inventory
├── docs/                    # Screenshot and project documentation
├── scripts/                 # Native build scripts
├── tests/                   # Unit tests
├── ui/                      # PySide6 desktop interface
├── .gitignore
├── LICENSE
├── GITHUB_UPLOAD.md          # First-time GitHub upload guide
├── README.md
├── SECURITY.md
├── CONTRIBUTING.md
├── CODE_OF_CONDUCT.md
├── requirements.txt
├── requirements-build.txt
├── SystemScope.spec
└── main.py
```

## Known limitations

- Software inventory is best-effort and depends on the operating system and available package managers.
- Folder sizes are logical totals of scanned regular files, not physical disk allocation.
- Hard links may be counted more than once.
- Very large scans can take time; begin with a small test folder.
- Some system metrics are unavailable on certain hardware or operating systems.
- GUI behavior and packaging must be tested on the actual target OS.

## Contributing

Bug reports, documentation improvements, and carefully scoped pull requests are welcome. Please read [`CONTRIBUTING.md`](CONTRIBUTING.md) before opening a pull request, and use the issue templates when reporting a problem.

## Security

Please read [`SECURITY.md`](SECURITY.md) for responsible vulnerability reporting. Do not publish private device information, access tokens, passwords, or sensitive scan reports in public issues.

## License

This project is distributed under the [MIT License](LICENSE). Review the license before redistributing or incorporating the code into another project.

---

<div align="center">
  <strong>SystemScope 1.0.0</strong><br />
  <sub>HEXMORA · Local insight. Clear visibility.</sub>
</div>
