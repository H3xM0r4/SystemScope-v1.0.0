# Changelog

Notable changes to SystemScope are documented here.

## [1.0.0] - 2026-11-12

### Added
- Local-first desktop dashboard for live CPU, memory, disk, network, and disk I/O metrics.
- Recent metric trend lines for live monitoring.
- Storage insights, file metadata explorer, and best-effort software inventory.
- Explicit SHA-256 hashing and basic permission inspection.
- CSV and JSON report export.
- HEXMORA visual branding and version 1.0 display.
- Native build scripts and GitHub Actions workflows for supported operating systems.

### Safety
- Read-only scanning by default.
- No telemetry or automatic scan uploads.
- Symlinks skipped during traversal by default.
