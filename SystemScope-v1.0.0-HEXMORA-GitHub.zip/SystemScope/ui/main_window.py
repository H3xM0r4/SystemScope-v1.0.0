from __future__ import annotations

import os
import platform
import socket
from collections import defaultdict
from pathlib import Path

import psutil
from PySide6.QtCore import Qt, QThread, Signal, QTimer, QSize
from PySide6.QtGui import QPainter, QPainterPath, QColor, QPen, QLinearGradient
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFrame, QStackedWidget, QTableWidget, QTableWidgetItem, QFileDialog,
    QMessageBox, QLineEdit, QProgressBar, QHeaderView, QFormLayout,
    QComboBox, QScrollArea, QSizePolicy
)

from core.system_info import get_system_info, get_volumes
from core.scanner import scan_folder, format_bytes, sha256_file, export_json, export_csv
from core.inventory import get_installed_software

GOLD = "#D6B45B"
CYAN = "#48D9F5"
STYLE = f"""
* {{ font-family: 'Inter', 'Segoe UI', Arial; font-size: 13px; }}
QMainWindow, QWidget {{ background: #080E18; color: #E7EDF6; }}
QFrame#Sidebar {{ background: #0B1321; border-right: 1px solid #1D2A3C; }}
QLabel#Brand {{ color: #F1D58A; font-size: 22px; font-weight: 900; letter-spacing: 2.4px; }}
QLabel#Eyebrow {{ color: #8192A9; font-size: 10px; font-weight: 800; letter-spacing: 2px; }}
QLabel#Muted {{ color: #91A0B5; }}
QLabel#PageTitle {{ color: #F4F7FC; font-size: 28px; font-weight: 800; }}
QLabel#Metric {{ color: #F1D58A; font-size: 29px; font-weight: 800; }}
QLabel#CardTitle {{ color: #A6B5C9; font-size: 10px; font-weight: 800; letter-spacing: 1.3px; }}
QFrame#Panel {{ background: #101B2B; border: 1px solid #23344A; border-radius: 16px; }}
QFrame#MetricCard {{ background: #111E30; border: 1px solid #263A52; border-radius: 15px; }}
QFrame#MetricCard:hover {{ border: 1px solid #4C7895; background: #14243A; }}
QFrame#LiveMetricCard {{ background: #0E1B2B; border: 1px solid #29445A; border-radius: 14px; }}
QPushButton {{ background: #17263A; color: #E4ECF7; border: 1px solid #30445D; border-radius: 9px; padding: 10px 14px; font-weight: 650; }}
QPushButton:hover {{ border: 1px solid {CYAN}; color: {CYAN}; background: #1A3046; }}
QPushButton#Primary {{ background: #D6B45B; color: #101722; font-weight: 850; border: none; }}
QPushButton#Primary:hover {{ background: #F0D27E; color: #101722; }}
QPushButton#Nav {{ text-align: left; padding: 13px 14px; background: transparent; border: 1px solid transparent; color: #A9B8CC; }}
QPushButton#Nav:hover {{ background: #14243A; color: #E9D18B; border-color: #253B53; }}
QPushButton#Nav[active="true"] {{ background: #1A2A3D; color: #F1D58A; border: 1px solid #3C5269; border-left: 3px solid {GOLD}; }}
QLineEdit, QComboBox {{ background: #0D1929; color: #F1F5FB; border: 1px solid #2A3C53; border-radius: 8px; padding: 10px; selection-background-color: #28546B; }}
QLineEdit:focus, QComboBox:focus {{ border: 1px solid {CYAN}; }}
QTableWidget {{ background: #0D1726; alternate-background-color: #111F31; gridline-color: #24354A; border: 1px solid #273B52; border-radius: 10px; selection-background-color: #254A60; selection-color: #FFFFFF; }}
QHeaderView::section {{ background: #17273B; color: #E6CB82; padding: 10px; border: none; border-bottom: 1px solid #30465E; font-weight: 800; }}
QProgressBar {{ background: #26374A; border: none; border-radius: 5px; text-align: center; height: 8px; color: #DCE7F5; }}
QProgressBar::chunk {{ background: {CYAN}; border-radius: 5px; }}
QScrollArea {{ border: none; background: transparent; }}
QToolTip {{ background: #18283B; color: #F1F5FB; border: 1px solid #3B536D; padding: 6px; }}
QScrollBar:vertical {{ background: #0B1421; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: #31465D; min-height: 24px; border-radius: 5px; }}
QScrollBar::handle:vertical:hover {{ background: #4C7895; }}
QLabel#Watermark {{ color: #667080; font-size: 10px; font-weight: 700; letter-spacing: 5px; padding: 3px 5px; }}
"""

class SparklineWidget(QWidget):
    """Small, dependency-free live history chart painted with Qt."""
    def __init__(self, color=CYAN, parent=None):
        super().__init__(parent)
        self.values = []
        self.line_color = QColor(color)
        self.setMinimumHeight(34)
        self.setMaximumHeight(42)
        self.setMinimumWidth(90)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)

    def sizeHint(self):
        return QSize(160, 38)

    def set_values(self, values):
        self.values = list(values[-48:])
        self.update()

    def paintEvent(self, event):
        if len(self.values) < 2:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        rect = self.rect().adjusted(2, 4, -2, -5)
        low = min(self.values)
        high = max(self.values)
        span = max(1.0, high - low)
        points = []
        for i, value in enumerate(self.values):
            x = rect.left() + (rect.width() * i / max(1, len(self.values) - 1))
            y = rect.bottom() - ((value - low) / span) * max(4, rect.height() - 3)
            points.append((x, y))
        line = QPainterPath()
        line.moveTo(*points[0])
        for point in points[1:]:
            line.lineTo(*point)
        area = QPainterPath(line)
        area.lineTo(points[-1][0], rect.bottom())
        area.lineTo(points[0][0], rect.bottom())
        area.closeSubpath()
        fill = QLinearGradient(0, rect.top(), 0, rect.bottom())
        fill_color = QColor(self.line_color)
        fill_color.setAlpha(65)
        fill.setColorAt(0, fill_color)
        fill_color.setAlpha(0)
        fill.setColorAt(1, fill_color)
        painter.fillPath(area, fill)
        pen = QPen(self.line_color, 2)
        pen.setCapStyle(Qt.RoundCap)
        pen.setJoinStyle(Qt.RoundJoin)
        painter.setPen(pen)
        painter.drawPath(line)
        painter.end()

def panel(title: str):
    frame = QFrame()
    frame.setObjectName("Panel")
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(17, 16, 17, 17)
    heading = QLabel(title.upper())
    heading.setObjectName("Eyebrow")
    layout.addWidget(heading)
    return frame, layout

def metric_card(title: str, value: str, detail: str = "", percent: int | None = None, chart: bool = False):
    frame = QFrame()
    frame.setObjectName("MetricCard")
    frame.setMinimumHeight(126)
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(17, 15, 17, 14)
    name = QLabel(title.upper())
    name.setObjectName("CardTitle")
    val = QLabel(value)
    val.setObjectName("Metric")
    desc = QLabel(detail)
    desc.setObjectName("Muted")
    desc.setWordWrap(True)
    layout.addWidget(name)
    layout.addWidget(val)
    layout.addWidget(desc)
    if percent is not None:
        bar = QProgressBar()
        bar.setRange(0, 100)
        bar.setValue(max(0, min(100, int(percent))))
        bar.setTextVisible(False)
        layout.addWidget(bar)
    if chart:
        spark = SparklineWidget()
        layout.addWidget(spark)
        frame.sparkline = spark
    layout.addStretch()
    return frame, val, desc

class ScanWorker(QThread):
    progress = Signal(int, str)
    completed = Signal(dict)
    failed = Signal(str)

    def __init__(self, folder: str, depth: int):
        super().__init__()
        self.folder, self.depth = folder, depth
        self._cancel = False

    def cancel(self):
        self._cancel = True

    def run(self):
        try:
            result = scan_folder(
                self.folder, self.depth,
                progress=lambda count, path: self.progress.emit(count, path),
                cancel_check=lambda: self._cancel,
            )
            self.completed.emit(result)
        except Exception as exc:
            self.failed.emit(str(exc))

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SystemScope — Performance Command Center")
        self.resize(1440, 900)
        self.setMinimumSize(1050, 700)
        self.scan_result = None
        self.worker = None
        self.software_rows = []
        self.nav_buttons = {}
        self.cpu_history = []
        self.ram_history = []
        self.disk_history = []
        self.network_history = []
        self.disk_io_history = []
        self._last_net_io = psutil.net_io_counters()
        self._last_disk_io = psutil.disk_io_counters()
        self._last_sample_time = __import__("time").monotonic()
        self._build_ui()
        self.refresh_dashboard()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_live_metrics)
        self.timer.start(2500)

    def _build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        outer = QHBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(238)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(17, 25, 17, 20)
        side.setSpacing(7)
        brand = QLabel("SYSTEMSCOPE")
        brand.setObjectName("Brand")
        side.addWidget(brand)
        tagline = QLabel("DEVICE INTELLIGENCE")
        tagline.setObjectName("Eyebrow")
        side.addWidget(tagline)
        side.addSpacing(27)

        nav_title = QLabel("WORKSPACE")
        nav_title.setObjectName("Eyebrow")
        side.addWidget(nav_title)
        self.stack = QStackedWidget()
        self.pages = {}
        nav_items = [
            ("◈   Overview", self._dashboard_page),
            ("▤   File Explorer", self._explorer_page),
            ("▦   Storage Insights", self._storage_page),
            ("▣   Software Inventory", self._software_page),
            ("◇   Security Center", self._security_page),
            ("⚙   Settings & Privacy", self._settings_page),
        ]
        for index, (name, builder) in enumerate(nav_items):
            page = builder()
            self.pages[name] = page
            self.stack.addWidget(page)
            button = QPushButton(name)
            button.setObjectName("Nav")
            button.setProperty("active", index == 0)
            button.clicked.connect(lambda checked=False, n=name: self.show_page(n))
            self.nav_buttons[name] = button
            side.addWidget(button)
        side.addStretch()
        status_frame = QFrame()
        status_frame.setStyleSheet("background:#171e28;border:1px solid #2b3340;border-radius:10px;")
        status_layout = QVBoxLayout(status_frame)
        status_layout.setContentsMargins(12, 10, 12, 10)
        status_layout.addWidget(QLabel("●  LOCAL MODE"))
        small = QLabel("Read-only scanning\nNo automatic uploads")
        small.setObjectName("Muted")
        status_layout.addWidget(small)
        side.addWidget(status_frame)
        version = QLabel("SYSTEMSCOPE  •  VERSION 1.0")
        version.setObjectName("Muted")
        side.addWidget(version)

        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(27, 22, 27, 24)
        content_layout.setSpacing(10)
        top = QHBoxLayout()
        top_label = QLabel("SYSTEM OVERVIEW  /  LOCAL DEVICE")
        top_label.setObjectName("Eyebrow")
        self.clock_label = QLabel("LIVE DEVICE METRICS")
        self.clock_label.setObjectName("Muted")
        top.addWidget(top_label)
        top.addStretch()
        top.addWidget(self.clock_label)
        content_layout.addLayout(top)
        content_layout.addWidget(self.stack)

        # Subtle HEXMORA brand watermark in the application footer.
        watermark_row = QHBoxLayout()
        watermark_row.addStretch()
        watermark = QLabel("HEXMORA")
        watermark.setObjectName("Watermark")
        watermark.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        watermark_row.addWidget(watermark)
        content_layout.addLayout(watermark_row)

        outer.addWidget(sidebar)
        outer.addWidget(content, 1)

    def _heading(self, title, subtitle):
        box = QWidget()
        layout = QVBoxLayout(box)
        layout.setContentsMargins(0, 0, 0, 13)
        title_label = QLabel(title)
        title_label.setObjectName("PageTitle")
        desc = QLabel(subtitle)
        desc.setObjectName("Muted")
        layout.addWidget(title_label)
        layout.addWidget(desc)
        return box

    def _table(self, headers):
        table = QTableWidget(0, len(headers))
        table.setHorizontalHeaderLabels(headers)
        table.setAlternatingRowColors(True)
        table.setSelectionBehavior(QTableWidget.SelectRows)
        table.setSelectionMode(QTableWidget.SingleSelection)
        table.setEditTriggers(QTableWidget.NoEditTriggers)
        table.verticalHeader().setVisible(False)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        table.horizontalHeader().setStretchLastSection(True)
        return table

    def _fill_table(self, table, rows):
        table.setSortingEnabled(False)
        table.setRowCount(0)
        for row_data in rows:
            row = table.rowCount()
            table.insertRow(row)
            for col, value in enumerate(row_data):
                item = QTableWidgetItem(str(value))
                item.setToolTip(str(value))
                table.setItem(row, col, item)
        table.resizeColumnsToContents()
        table.setSortingEnabled(True)

    def _dashboard_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._heading("System Overview", "Real-time system telemetry, resource trends and hardware intelligence."))
        cards = QHBoxLayout()
        self.cpu_card, self.cpu_value, self.cpu_detail = metric_card("Processor load", "—", "Loading…", 0, chart=True)
        self.ram_card, self.ram_value, self.ram_detail = metric_card("Memory usage", "—", "Loading…", 0, chart=True)
        self.disk_card, self.disk_value, self.disk_detail = metric_card("System drive", "—", "Loading…", 0, chart=True)
        self.uptime_card, self.uptime_value, self.uptime_detail = metric_card("System uptime", "—", "Since last boot")
        for card in (self.cpu_card, self.ram_card, self.disk_card, self.uptime_card):
            cards.addWidget(card)
        layout.addLayout(cards)

        live_row = QHBoxLayout()
        self.network_card, self.network_value, self.network_detail = metric_card(
            "Network throughput", "—", "↓ Receive  •  ↑ Send", chart=True
        )
        self.disk_io_card, self.disk_io_value, self.disk_io_detail = metric_card(
            "Disk I/O", "—", "Read  •  Write throughput", chart=True
        )
        self.network_card.setObjectName("LiveMetricCard")
        self.disk_io_card.setObjectName("LiveMetricCard")
        live_row.addWidget(self.network_card, 1)
        live_row.addWidget(self.disk_io_card, 1)
        layout.addLayout(live_row)

        lower = QHBoxLayout()
        system_panel, system_layout = panel("Hardware & operating system")
        self.info_labels = {}
        form = QFormLayout()
        form.setVerticalSpacing(11)
        for key in get_system_info():
            value = QLabel("—")
            value.setTextInteractionFlags(Qt.TextSelectableByMouse)
            value.setWordWrap(True)
            self.info_labels[key] = value
            form.addRow(QLabel(key), value)
        system_layout.addLayout(form)
        lower.addWidget(system_panel, 1)

        health_panel, health_layout = panel("Memory & processor details")
        self.detail_labels = {}
        for key in ["Available memory", "Used memory", "Swap usage", "CPU frequency", "Physical cores", "Logical cores", "Boot time"]:
            row = QHBoxLayout()
            k = QLabel(key)
            k.setObjectName("Muted")
            v = QLabel("—")
            v.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            v.setTextInteractionFlags(Qt.TextSelectableByMouse)
            row.addWidget(k)
            row.addStretch()
            row.addWidget(v)
            health_layout.addLayout(row)
            self.detail_labels[key] = v
        lower.addWidget(health_panel, 1)
        layout.addLayout(lower, 1)

        volume_panel, volume_layout = panel("Mounted storage volumes")
        self.volume_table = self._table(["Volume / Device", "Mount point", "File system", "Used", "Capacity"])
        self.volume_table.setMaximumHeight(185)
        volume_layout.addWidget(self.volume_table)
        layout.addWidget(volume_panel, 1)

        refresh = QPushButton("↻   Refresh device details")
        refresh.setObjectName("Primary")
        refresh.clicked.connect(self.refresh_dashboard)
        layout.addWidget(refresh, alignment=Qt.AlignRight)
        return page

    def refresh_dashboard(self):
        try:
            cpu = psutil.cpu_percent(interval=None)
            mem = psutil.virtual_memory()
            disk = psutil.disk_usage(os.path.abspath(os.sep))
            self.cpu_value.setText(f"{cpu:.0f}%")
            self.cpu_detail.setText(f"{psutil.cpu_count(logical=True) or '—'} logical threads")
            self._set_card_progress(self.cpu_card, cpu)
            self.ram_value.setText(f"{mem.percent:.0f}%")
            self.ram_detail.setText(f"{format_bytes(mem.used)} of {format_bytes(mem.total)}")
            self._set_card_progress(self.ram_card, mem.percent)
            self.disk_value.setText(f"{disk.percent:.0f}%")
            self.disk_detail.setText(f"{format_bytes(disk.free)} free of {format_bytes(disk.total)}")
            self._set_card_progress(self.disk_card, disk.percent)
            boot = psutil.boot_time()
            uptime_seconds = max(0, int(__import__("time").time() - boot))
            days, rem = divmod(uptime_seconds, 86400)
            hours, rem = divmod(rem, 3600)
            minutes = rem // 60
            uptime = f"{days}d {hours}h {minutes}m"
            self.uptime_value.setText(uptime)
            self.uptime_detail.setText("Since last system boot")
            for key, value in get_system_info().items():
                self.info_labels[key].setText(str(value))
            vm = psutil.virtual_memory()
            swap = psutil.swap_memory()
            freq = psutil.cpu_freq()
            values = {
                "Available memory": format_bytes(vm.available),
                "Used memory": format_bytes(vm.used),
                "Swap usage": f"{swap.percent:.0f}%  ({format_bytes(swap.used)} / {format_bytes(swap.total)})",
                "CPU frequency": f"{freq.current:.0f} MHz" if freq else "Not reported",
                "Physical cores": str(psutil.cpu_count(logical=False) or "Unknown"),
                "Logical cores": str(psutil.cpu_count(logical=True) or "Unknown"),
                "Boot time": __import__("datetime").datetime.fromtimestamp(boot).astimezone().strftime("%Y-%m-%d %H:%M"),
            }
            for key, value in values.items():
                self.detail_labels[key].setText(value)
            self._fill_table(self.volume_table, [
                [r["device"], r["mountpoint"], r["filesystem"], r["used"], r["capacity"]]
                for r in get_volumes()
            ])
        except Exception as exc:
            QMessageBox.warning(self, "Dashboard refresh", str(exc))

    def _set_card_progress(self, card, value):
        bars = card.findChildren(QProgressBar)
        if bars:
            bars[0].setValue(int(value))

    @staticmethod
    def _rate_text(bytes_per_second: float) -> str:
        value = max(0.0, float(bytes_per_second))
        if value >= 1024 ** 2:
            return f"{value / (1024 ** 2):.1f} MB/s"
        if value >= 1024:
            return f"{value / 1024:.0f} KB/s"
        return f"{value:.0f} B/s"

    def _push_history(self, key, value):
        history = getattr(self, key)
        history.append(float(value))
        del history[:-48]

    def refresh_live_metrics(self):
        try:
            now = __import__("time").monotonic()
            elapsed = max(0.1, now - self._last_sample_time)
            cpu = psutil.cpu_percent(interval=None)
            mem = psutil.virtual_memory()
            disk = psutil.disk_usage(os.path.abspath(os.sep))

            self.cpu_value.setText(f"{cpu:.0f}%")
            self.cpu_detail.setText(
                f"{psutil.cpu_count(logical=True) or '—'} logical threads  •  live sample"
            )
            self._set_card_progress(self.cpu_card, cpu)
            self.ram_value.setText(f"{mem.percent:.0f}%")
            self.ram_detail.setText(f"{format_bytes(mem.used)} used  /  {format_bytes(mem.total)}")
            self._set_card_progress(self.ram_card, mem.percent)
            self.disk_value.setText(f"{disk.percent:.0f}%")
            self.disk_detail.setText(f"{format_bytes(disk.free)} available")
            self._set_card_progress(self.disk_card, disk.percent)

            self._push_history("cpu_history", cpu)
            self._push_history("ram_history", mem.percent)
            self._push_history("disk_history", disk.percent)
            self.cpu_card.sparkline.set_values(self.cpu_history)
            self.ram_card.sparkline.set_values(self.ram_history)
            self.disk_card.sparkline.set_values(self.disk_history)

            current_net = psutil.net_io_counters()
            current_disk_io = psutil.disk_io_counters()
            if current_net and self._last_net_io:
                recv_rate = max(0, current_net.bytes_recv - self._last_net_io.bytes_recv) / elapsed
                sent_rate = max(0, current_net.bytes_sent - self._last_net_io.bytes_sent) / elapsed
            else:
                recv_rate = sent_rate = 0.0

            if current_disk_io and self._last_disk_io:
                read_rate = max(0, current_disk_io.read_bytes - self._last_disk_io.read_bytes) / elapsed
                write_rate = max(0, current_disk_io.write_bytes - self._last_disk_io.write_bytes) / elapsed
            else:
                read_rate = write_rate = 0.0

            network_total = recv_rate + sent_rate
            disk_total = read_rate + write_rate
            self.network_value.setText(self._rate_text(network_total))
            self.network_detail.setText(
                f"↓ {self._rate_text(recv_rate)} receive   •   ↑ {self._rate_text(sent_rate)} send"
            )
            self.disk_io_value.setText(self._rate_text(disk_total))
            self.disk_io_detail.setText(
                f"Read {self._rate_text(read_rate)}   •   Write {self._rate_text(write_rate)}"
            )

            self._push_history("network_history", network_total)
            self._push_history("disk_io_history", disk_total)
            self.network_card.sparkline.set_values(self.network_history)
            self.disk_io_card.sparkline.set_values(self.disk_io_history)

            self._last_net_io = current_net
            self._last_disk_io = current_disk_io
            self._last_sample_time = now
            self.clock_label.setText("●  LIVE MONITORING  •  2.5 SEC REFRESH")
        except Exception:
            self.clock_label.setText("LIVE METRICS PARTIALLY UNAVAILABLE")

    def _explorer_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._heading("File Explorer", "Inspect files and folders without changing them."))
        controls = QHBoxLayout()
        self.folder_input = QLineEdit(str(Path.home()))
        self.folder_input.setPlaceholderText("Folder path…")
        browse = QPushButton("Browse folder")
        browse.clicked.connect(self.choose_folder)
        self.depth_combo = QComboBox()
        self.depth_combo.addItems(["5", "10", "12", "20", "30"])
        self.depth_combo.setCurrentText("12")
        self.scan_button = QPushButton("Start scan")
        self.scan_button.setObjectName("Primary")
        self.scan_button.clicked.connect(self.start_scan)
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.clicked.connect(self.cancel_scan)
        self.cancel_button.setEnabled(False)
        for widget in [self.folder_input, browse, QLabel("Depth"), self.depth_combo, self.scan_button, self.cancel_button]:
            controls.addWidget(widget, 1 if widget is self.folder_input else 0)
        layout.addLayout(controls)
        self.scan_status = QLabel("Select a folder. Start with Downloads or a small test folder.")
        self.scan_status.setObjectName("Muted")
        layout.addWidget(self.scan_status)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 0)
        self.progress_bar.hide()
        layout.addWidget(self.progress_bar)
        stats = QHBoxLayout()
        self.scan_summary = QLabel("No scan results yet")
        self.scan_summary.setObjectName("Metric")
        stats.addWidget(self.scan_summary)
        stats.addStretch()
        json_btn = QPushButton("Export JSON")
        json_btn.clicked.connect(self.save_json)
        csv_btn = QPushButton("Export CSV")
        csv_btn.clicked.connect(self.save_csv)
        stats.addWidget(json_btn)
        stats.addWidget(csv_btn)
        layout.addLayout(stats)
        filters = QHBoxLayout()
        self.file_filter = QLineEdit()
        self.file_filter.setPlaceholderText("Search name, path or extension…")
        self.file_filter.textChanged.connect(self.apply_file_filter)
        self.extension_filter = QComboBox()
        self.extension_filter.addItem("All file types")
        self.extension_filter.currentTextChanged.connect(self.apply_file_filter)
        filters.addWidget(self.file_filter, 2)
        filters.addWidget(self.extension_filter, 1)
        layout.addLayout(filters)
        self.file_table = self._table(["Name", "Type", "Size", "Hidden", "Readable", "Writable", "Modified", "Full path"])
        layout.addWidget(self.file_table, 1)
        return page

    def choose_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Select folder", self.folder_input.text())
        if folder:
            self.folder_input.setText(folder)

    def start_scan(self):
        folder = self.folder_input.text().strip()
        if not folder or not Path(folder).expanduser().exists():
            QMessageBox.warning(self, "Invalid folder", "Choose an existing folder.")
            return
        self.scan_button.setEnabled(False)
        self.cancel_button.setEnabled(True)
        self.progress_bar.show()
        self.scan_status.setText("Scanning folder metadata…")
        self.worker = ScanWorker(folder, int(self.depth_combo.currentText()))
        self.worker.progress.connect(self.scan_progress)
        self.worker.completed.connect(self.scan_completed)
        self.worker.failed.connect(self.scan_failed)
        self.worker.start()

    def scan_progress(self, count, current_path):
        self.scan_status.setText(f"Indexed {count:,} files  •  {current_path}")

    def scan_completed(self, result):
        self.scan_result = result
        self.scan_button.setEnabled(True)
        self.cancel_button.setEnabled(False)
        self.progress_bar.hide()
        self.scan_summary.setText(
            f"{result['total_files']:,} files  •  {result['total_folders']:,} folders  •  "
            f"{format_bytes(result['total_size_bytes'])} total"
        )
        self.scan_status.setText(
            f"{'Cancelled — partial results' if result.get('cancelled') else 'Scan complete'}  •  "
            f"{len(result['errors'])} access/scan issue(s)"
        )
        extensions = sorted({item["extension"] for item in result["files"]})
        self.extension_filter.blockSignals(True)
        self.extension_filter.clear()
        self.extension_filter.addItem("All file types")
        self.extension_filter.addItems(extensions)
        self.extension_filter.blockSignals(False)
        self.apply_file_filter()
        self.update_storage_page()

    def scan_failed(self, message):
        self.scan_button.setEnabled(True)
        self.cancel_button.setEnabled(False)
        self.progress_bar.hide()
        QMessageBox.warning(self, "Scan failed", message)
        self.scan_status.setText("Scan failed.")

    def cancel_scan(self):
        if self.worker and self.worker.isRunning():
            self.worker.cancel()
            self.scan_status.setText("Cancelling after the current file…")

    def apply_file_filter(self):
        if not self.scan_result:
            return
        query = self.file_filter.text().casefold().strip()
        ext = self.extension_filter.currentText() if hasattr(self, "extension_filter") else "All file types"
        rows = []
        for item in self.scan_result["files"]:
            searchable = f"{item['name']} {item['path']} {item['extension']}".casefold()
            if query and query not in searchable:
                continue
            if ext != "All file types" and item["extension"] != ext:
                continue
            rows.append([
                item["name"], item["extension"], item["size"],
                "Yes" if item["hidden"] else "No",
                "Yes" if item["readable"] else "No",
                "Yes" if item["writable"] else "No",
                item["modified"], item["path"]
            ])
        self._fill_table(self.file_table, rows)

    def save_json(self):
        if not self.scan_result:
            QMessageBox.information(self, "No scan", "Run a folder scan first.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export scan", "systemscope-report.json", "JSON (*.json)")
        if path:
            try:
                export_json(self.scan_result, path)
                QMessageBox.information(self, "Export complete", f"Saved to:\n{path}")
            except Exception as exc:
                QMessageBox.warning(self, "Export failed", str(exc))

    def save_csv(self):
        if not self.scan_result:
            QMessageBox.information(self, "No scan", "Run a folder scan first.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export files", "systemscope-files.csv", "CSV (*.csv)")
        if path:
            try:
                export_csv(self.scan_result["files"], path)
                QMessageBox.information(self, "Export complete", f"Saved to:\n{path}")
            except Exception as exc:
                QMessageBox.warning(self, "Export failed", str(exc))

    def _storage_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._heading("Storage Insights", "Understand where scanned folder space is being used."))
        self.storage_summary = QLabel("Run a scan in File Explorer to generate storage insights.")
        self.storage_summary.setObjectName("Metric")
        layout.addWidget(self.storage_summary)
        row = QHBoxLayout()
        ext_panel, ext_layout = panel("File type distribution")
        self.extension_table = self._table(["Extension", "Files", "Total size"])
        ext_layout.addWidget(self.extension_table)
        row.addWidget(ext_panel, 1)
        folder_panel, folder_layout = panel("Largest folders")
        self.folder_table = self._table(["Folder", "Size", "Full path"])
        folder_layout.addWidget(self.folder_table)
        row.addWidget(folder_panel, 1)
        layout.addLayout(row, 1)
        largest_panel, largest_layout = panel("Largest files")
        self.largest_table = self._table(["File", "Size", "Type", "Full path"])
        largest_layout.addWidget(self.largest_table)
        layout.addWidget(largest_panel, 1)
        return page

    def update_storage_page(self):
        if not self.scan_result:
            return
        files = self.scan_result["files"]
        by_ext = defaultdict(lambda: {"count": 0, "size": 0})
        for item in files:
            by_ext[item["extension"]]["count"] += 1
            by_ext[item["extension"]]["size"] += item["size_bytes"]
        ext_rows = [
            [ext, data["count"], format_bytes(data["size"])]
            for ext, data in sorted(by_ext.items(), key=lambda pair: pair[1]["size"], reverse=True)
        ]
        self._fill_table(self.extension_table, ext_rows)
        folder_rows = [
            [f["name"], f["size"], f["path"]]
            for f in self.scan_result["folders"][:30]
        ]
        self._fill_table(self.folder_table, folder_rows)
        largest_rows = [
            [f["name"], f["size"], f["extension"], f["path"]]
            for f in files[:30]
        ]
        self._fill_table(self.largest_table, largest_rows)
        self.storage_summary.setText(
            f"{len(files):,} files  •  {len(by_ext):,} file types  •  "
            f"{format_bytes(self.scan_result['total_size_bytes'])} indexed"
        )

    def _software_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._heading("Software Inventory", "A best-effort inventory from local operating-system sources."))
        bar = QHBoxLayout()
        self.software_filter = QLineEdit()
        self.software_filter.setPlaceholderText("Search application or version…")
        self.software_filter.textChanged.connect(self.filter_software)
        refresh = QPushButton("Scan installed software")
        refresh.setObjectName("Primary")
        refresh.clicked.connect(self.load_software)
        bar.addWidget(self.software_filter, 1)
        bar.addWidget(refresh)
        layout.addLayout(bar)
        self.software_status = QLabel("Inventory has not been scanned yet.")
        self.software_status.setObjectName("Muted")
        layout.addWidget(self.software_status)
        self.software_table = self._table(["Application", "Version", "Inventory source"])
        layout.addWidget(self.software_table, 1)
        return page

    def load_software(self):
        self.software_status.setText("Reading installed application records…")
        self.software_rows = get_installed_software()
        self.software_status.setText(f"{len(self.software_rows):,} entries found. Coverage varies by OS and package source.")
        self.filter_software()

    def filter_software(self):
        query = self.software_filter.text().casefold().strip()
        rows = [[r["name"], r["version"], r["source"]] for r in self.software_rows
                if query in f"{r['name']} {r['version']} {r['source']}".casefold()]
        self._fill_table(self.software_table, rows)

    def _security_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._heading("Security Center", "Basic integrity and permission checks — not an antivirus scanner."))
        hash_panel, hash_layout = panel("SHA-256 file integrity")
        note = QLabel("Select a file to calculate its SHA-256 digest. The file is read only for this action.")
        note.setObjectName("Muted")
        note.setWordWrap(True)
        hash_layout.addWidget(note)
        row = QHBoxLayout()
        self.hash_path = QLineEdit()
        self.hash_path.setPlaceholderText("Choose a file path…")
        choose = QPushButton("Browse file")
        choose.clicked.connect(self.choose_hash_file)
        hash_btn = QPushButton("Calculate hash")
        hash_btn.setObjectName("Primary")
        hash_btn.clicked.connect(self.calculate_hash)
        row.addWidget(self.hash_path, 1)
        row.addWidget(choose)
        row.addWidget(hash_btn)
        hash_layout.addLayout(row)
        self.hash_result = QLineEdit()
        self.hash_result.setReadOnly(True)
        self.hash_result.setPlaceholderText("SHA-256 output")
        hash_layout.addWidget(self.hash_result)
        layout.addWidget(hash_panel)
        safety_panel, safety_layout = panel("Audit scope & limitations")
        messages = [
            "Read-only: no file deletion, quarantine, permission changes or automatic cleanup.",
            "Permission status: basic current-user read/write/execute checks only; not a complete ACL audit.",
            "No malware verdicts: a hash by itself does not tell you whether a file is malicious.",
            "Sensitive locations and symbolic links are excluded from folder scans by default.",
            "No telemetry or automatic cloud uploads are implemented.",
        ]
        for message in messages:
            label = QLabel("•  " + message)
            label.setWordWrap(True)
            safety_layout.addWidget(label)
        layout.addWidget(safety_panel)
        layout.addStretch()
        return page

    def choose_hash_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Choose file")
        if path:
            self.hash_path.setText(path)

    def calculate_hash(self):
        path = self.hash_path.text().strip()
        if not path or not Path(path).is_file():
            QMessageBox.warning(self, "Invalid file", "Choose an existing file.")
            return
        try:
            self.hash_result.setText(sha256_file(path))
        except Exception as exc:
            QMessageBox.warning(self, "Hash failed", str(exc))

    def _settings_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._heading("Settings & Privacy", "Understand how SystemScope handles your device data."))
        privacy_panel, privacy_layout = panel("Privacy defaults")
        lines = [
            "All scans are local. No network upload or telemetry is implemented.",
            "Scanning is read-only; SystemScope does not alter scanned files.",
            "Run as your normal user. Root or Administrator access is not required.",
            "Symbolic links are skipped to avoid unexpected traversal.",
            "Common credential/configuration folders are excluded from scans.",
            "File metadata scans do not read file contents. Hashing reads content only after you request it.",
            "Folder size totals are logical sizes of discovered regular files; hard links can be counted more than once.",
        ]
        for line in lines:
            label = QLabel("•  " + line)
            label.setWordWrap(True)
            privacy_layout.addWidget(label)
        layout.addWidget(privacy_panel)
        about_panel, about_layout = panel("Application")
        about_layout.addWidget(QLabel("SystemScope v1.0 — Live Performance Edition"))
        about_layout.addWidget(QLabel("Python • PySide6 • psutil • cross-platform project structure"))
        about_layout.addWidget(QLabel("Target: Debian / Arch Linux • Windows • macOS"))
        layout.addWidget(about_panel)
        layout.addStretch()
        return page

    def show_page(self, name):
        self.stack.setCurrentWidget(self.pages[name])
        for nav_name, button in self.nav_buttons.items():
            button.setProperty("active", nav_name == name)
            button.style().unpolish(button)
            button.style().polish(button)
