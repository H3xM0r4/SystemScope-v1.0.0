$ErrorActionPreference = "Stop"

$RootDir = Split-Path -Parent $PSScriptRoot
Set-Location $RootDir

if (-not $env:OS -or $env:OS -ne "Windows_NT") {
    throw "Run this script on Windows PowerShell."
}

$Python = Get-Command py -ErrorAction SilentlyContinue
if ($Python) {
    py -3 -m venv .venv
    .\.venv\Scripts\python.exe -m pip install --upgrade pip
    .\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
    .\.venv\Scripts\python.exe -m unittest discover -s tests -v
    .\.venv\Scripts\python.exe -m compileall -q main.py core ui tests
    .\.venv\Scripts\python.exe -m PyInstaller --clean --noconfirm SystemScope.spec
} else {
    throw "Python Launcher 'py' not found. Install Python 3.10+ and enable Add Python to PATH."
}

New-Item -ItemType Directory -Force -Path release | Out-Null
if (Test-Path release\SystemScope-windows-x64.zip) {
    Remove-Item release\SystemScope-windows-x64.zip -Force
}
Compress-Archive -Path dist\SystemScope -DestinationPath release\SystemScope-windows-x64.zip

Write-Host ""
Write-Host "Build complete:"
Write-Host "  Application folder: $RootDir\dist\SystemScope\"
Write-Host "  Archive:            $RootDir\release\SystemScope-windows-x64.zip"
