#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ "$(uname -s)" != "Linux" ]]; then
  echo "Run this script on Linux (Debian/Ubuntu/Kali or Arch)." >&2
  exit 1
fi

PYTHON_BIN="${PYTHON_BIN:-python3}"
"$PYTHON_BIN" -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements-build.txt
python -m unittest discover -s tests -v
python -m compileall -q main.py core ui tests
python -m PyInstaller --clean --noconfirm SystemScope.spec

mkdir -p release
tar -czf release/SystemScope-linux-$(uname -m).tar.gz -C dist SystemScope
echo
echo "Build complete:"
echo "  Application folder: $ROOT_DIR/dist/SystemScope/"
echo "  Archive:            $ROOT_DIR/release/SystemScope-linux-$(uname -m).tar.gz"
