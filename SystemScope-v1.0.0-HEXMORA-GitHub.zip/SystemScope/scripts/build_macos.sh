#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "Run this script on macOS. A native macOS build cannot be made on Linux." >&2
  exit 1
fi

PYTHON_BIN="${PYTHON_BIN:-python3}"
"$PYTHON_BIN" -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements-build.txt
python -m unittest discover -s tests -v
python -m compileall -q main.py core ui tests
python -m PyInstaller --clean --noconfirm SystemScope.spec

mkdir -p release
ditto -c -k --sequesterRsrc --keepParent dist/SystemScope.app release/SystemScope-macos-$(uname -m).zip
echo
echo "Build complete:"
echo "  App bundle: $ROOT_DIR/dist/SystemScope.app"
echo "  Archive:    $ROOT_DIR/release/SystemScope-macos-$(uname -m).zip"
echo "Note: this build is not code-signed or notarized."
