# PyInstaller build configuration for SystemScope.
# Run this spec on the target operating system; PyInstaller is not a cross-compiler.

import sys

hiddenimports = []
# PySide6's PyInstaller hooks collect the Qt platform plugins needed by the GUI.
# Keep this list small; add hidden imports only if a future feature needs them.

a = Analysis(
    ["main.py"],
    pathex=["."],
    binaries=[],
    datas=[],
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="SystemScope",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name="SystemScope",
)

if sys.platform == "darwin":
    app = BUNDLE(
        coll,
        name="SystemScope.app",
        icon=None,
        bundle_identifier="org.systemscope.desktop",
    )
