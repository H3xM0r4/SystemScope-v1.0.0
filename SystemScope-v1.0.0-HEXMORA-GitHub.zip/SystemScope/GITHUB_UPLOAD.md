# Upload SystemScope to GitHub

This guide is for the first upload of SystemScope 1.0.0.

## 1. Create the GitHub repository

1. Sign in at <https://github.com/new>.
2. Repository name: `SystemScope`.
3. Choose **Public** or **Private**.
4. Do not initialize it with a README, `.gitignore`, or license (these are already included here).
5. Create the repository and keep its page open.

## 2. Extract this project

Extract the downloaded ZIP. Open a terminal inside the extracted `SystemScope` folder (the folder containing `main.py` and `README.md`).

On Linux, for example:

```bash
cd ~/Downloads
unzip SystemScope-v1.0.0-HEXMORA-GitHub.zip
cd SystemScope
```

## 3. Initialize Git and make the first commit

Install Git if needed on Debian, Ubuntu, or Kali:

```bash
sudo apt update
sudo apt install git -y
```

Then run:

```bash
git init
git add .
git status
git commit -m "Initial release: SystemScope 1.0.0"
git branch -M main
```

Review `git status` before committing. Do not upload passwords, API keys, private keys, personal files, or private scan reports.

## 4. Connect the GitHub repository

Copy the HTTPS repository URL from the GitHub page. Replace the example URL below with your own:

```bash
git remote add origin https://github.com/YOUR-USERNAME/SystemScope.git
git push -u origin main
```

GitHub may ask you to authenticate in your browser or with a personal access token. Never put a password or token directly into a command or commit it to this repository.

## 5. Check GitHub Actions

Open the repository's **Actions** tab. The CI workflow should run after the push. Check the job results and logs; a workflow file being present does not mean the remote build has passed.

## 6. Create the v1.0.0 release

Only after reviewing the repository and CI results, run:

```bash
git tag -a v1.0.0 -m "SystemScope 1.0.0"
git push origin v1.0.0
```

The build workflow is configured to build native packages on GitHub-hosted Linux, Windows, and macOS runners, then publish a GitHub Release if all build jobs succeed. Check **Actions** and **Releases** to confirm the result.

## Important notes

- Replace `YOUR-USERNAME` with your actual GitHub username.
- PyInstaller builds are native to the operating system running the build; do not expect a Linux build to produce a native Windows or macOS app.
- The macOS workflow target is Apple Silicon. Arch Linux builds should be performed on an Arch Linux machine.
- GUI testing and native packaged-app testing still need to be completed on the target operating systems.
