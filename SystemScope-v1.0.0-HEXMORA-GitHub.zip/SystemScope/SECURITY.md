# Security Policy

## Scope

SystemScope is a local-first system inspection utility. It is not antivirus software and does not guarantee that a device is secure.

## Reporting a vulnerability

Please do not publish exploitable vulnerabilities, private scan results, credentials, or personal device information in a public issue.

If GitHub private vulnerability reporting is enabled for this repository, use **Security → Report a vulnerability**. Otherwise, contact the repository maintainer privately through their GitHub profile and ask for a secure reporting channel. Include:

- A short description and potential impact.
- Affected version, operating system, and Python version.
- Reproduction steps or a minimal proof of concept.
- Any suggested mitigation.

Please allow maintainers reasonable time to investigate before public disclosure. Do not access, modify, or exfiltrate data that is not yours while validating a report.

## Supported versions

Security fixes are currently intended for the latest published version. Older versions may not receive updates.
