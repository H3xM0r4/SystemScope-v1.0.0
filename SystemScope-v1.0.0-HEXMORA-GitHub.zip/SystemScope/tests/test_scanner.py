import tempfile
import unittest
from pathlib import Path
from core.scanner import scan_folder, sha256_file

class ScannerTests(unittest.TestCase):
    def test_scan_metadata(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "hello.txt").write_text("hello", encoding="utf-8")
            (root / ".hidden").write_text("hidden", encoding="utf-8")
            result = scan_folder(root)
            self.assertEqual(result["total_files"], 2)
            self.assertEqual(result["hidden_files"], 1)

    def test_hash(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "hello.txt"
            path.write_text("hello", encoding="utf-8")
            self.assertEqual(
                sha256_file(path),
                "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824"
            )

if __name__ == "__main__":
    unittest.main()
