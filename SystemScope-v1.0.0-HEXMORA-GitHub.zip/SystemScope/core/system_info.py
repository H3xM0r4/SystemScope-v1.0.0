import platform
import psutil
import socket
import os

def get_system_info() -> dict:
    vm = psutil.virtual_memory()
    try:
        disk = psutil.disk_usage(os.path.abspath(os.sep))
        disk_text = f"{disk.percent}% used ({disk.used // (1024**3)} GB / {disk.total // (1024**3)} GB)"
    except OSError:
        disk_text = "Unavailable"
    return {
        "Operating system": f"{platform.system()} {platform.release()}",
        "Platform": platform.platform(),
        "Hostname": socket.gethostname(),
        "Architecture": platform.machine(),
        "Processor": platform.processor() or "Not reported",
        "Physical CPU cores": psutil.cpu_count(logical=False) or "Unknown",
        "Logical CPU cores": psutil.cpu_count(logical=True) or "Unknown",
        "Total memory": f"{vm.total / (1024**3):.1f} GB",
        "Root volume": disk_text,
    }

def get_volumes() -> list[dict]:
    rows = []
    for part in psutil.disk_partitions(all=False):
        try:
            usage = psutil.disk_usage(part.mountpoint)
            rows.append({
                "device": part.device,
                "mountpoint": part.mountpoint,
                "filesystem": part.fstype or "Unknown",
                "used": f"{usage.percent}%",
                "capacity": f"{usage.used / (1024**3):.1f} / {usage.total / (1024**3):.1f} GB",
                "free_bytes": usage.free,
            })
        except (PermissionError, OSError):
            continue
    return rows
