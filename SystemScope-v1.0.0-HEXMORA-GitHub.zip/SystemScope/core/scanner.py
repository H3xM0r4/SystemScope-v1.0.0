from __future__ import annotations

import csv
import hashlib
import json
import os
import stat
import time
from pathlib import Path
from datetime import datetime
from typing import Callable

# Conservative directory-name exclusions. These are matched case-insensitively.
SENSITIVE_DIRS = {
    ".ssh", ".gnupg", ".aws", ".azure", ".config",
    "keychains", "library/keychains", "credentials",
}

def format_bytes(value: int) -> str:
    amount = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if amount < 1024 or unit == "TB":
            return f"{amount:.1f} {unit}" if unit != "B" else f"{int(amount)} B"
        amount /= 1024
    return f"{amount:.1f} TB"

def _is_sensitive(path: Path) -> bool:
    parts = [p.casefold() for p in path.parts]
    return any(part in SENSITIVE_DIRS for part in parts)

def scan_folder(
    root: str | Path,
    max_depth: int = 12,
    progress: Callable[[int, str], None] | None = None,
    cancel_check: Callable[[], bool] | None = None,
) -> dict:
    root = Path(root).expanduser().resolve(strict=True)
    if not root.is_dir():
        raise ValueError("Please choose a folder, not a file.")
    if _is_sensitive(root):
        raise PermissionError("This folder is excluded because it may contain sensitive data.")

    files, folders, errors = [], [], []
    folder_sizes: dict[str, int] = {}
    count = 0
    root_depth = len(root.parts)

    def onerror(error):
        errors.append(f"{getattr(error, 'filename', 'unknown')}: {error}")

    for current, dirnames, filenames in os.walk(root, topdown=True, followlinks=False, onerror=onerror):
        current_path = Path(current)
        depth = len(current_path.parts) - root_depth
        if depth >= max_depth:
            dirnames[:] = []
        else:
            safe_dirs = []
            for name in dirnames:
                candidate = current_path / name
                try:
                    if candidate.is_symlink() or name.casefold() in SENSITIVE_DIRS:
                        continue
                    safe_dirs.append(name)
                except OSError as exc:
                    errors.append(f"{candidate}: {exc}")
            dirnames[:] = safe_dirs

        try:
            folder_stat = current_path.stat()
            folders.append({
                "name": current_path.name or str(current_path),
                "path": str(current_path),
                "modified": datetime.fromtimestamp(folder_stat.st_mtime).astimezone().isoformat(timespec="seconds"),
                "depth": depth,
            })
        except OSError as exc:
            errors.append(f"{current_path}: {exc}")

        local_size = 0
        for name in filenames:
            if cancel_check and cancel_check():
                return {
                    "root": str(root), "files": files, "folders": folders,
                    "errors": errors, "cancelled": True,
                    "total_files": len(files), "total_folders": len(folders),
                    "total_size_bytes": sum(item["size_bytes"] for item in files),
                }
            path = current_path / name
            try:
                if path.is_symlink():
                    continue
                st = path.stat(follow_symlinks=False)
                if not stat.S_ISREG(st.st_mode):
                    continue
                hidden = name.startswith(".")
                if os.name == "nt":
                    hidden = hidden or bool(getattr(st, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_HIDDEN", 2))
                item = {
                    "name": name,
                    "path": str(path),
                    "extension": path.suffix.lower() or "(no extension)",
                    "size_bytes": st.st_size,
                    "size": format_bytes(st.st_size),
                    "hidden": hidden,
                    "modified": datetime.fromtimestamp(st.st_mtime).astimezone().isoformat(timespec="seconds"),
                    "readable": os.access(path, os.R_OK),
                    "writable": os.access(path, os.W_OK),
                    "executable": os.access(path, os.X_OK),
                }
                files.append(item)
                local_size += st.st_size
                count += 1
            except OSError as exc:
                errors.append(f"{path}: {exc}")
        folder_sizes[str(current_path)] = local_size
        if progress:
            progress(count, str(current_path))

    # Add descendants' logical sizes to their parent folders.
    for folder_path in sorted(folder_sizes, key=lambda p: len(Path(p).parts), reverse=True):
        parent = str(Path(folder_path).parent)
        if parent in folder_sizes:
            folder_sizes[parent] += folder_sizes[folder_path]

    for folder in folders:
        folder["size_bytes"] = folder_sizes.get(folder["path"], 0)
        folder["size"] = format_bytes(folder["size_bytes"])

    files.sort(key=lambda item: item["size_bytes"], reverse=True)
    folders.sort(key=lambda item: item["size_bytes"], reverse=True)
    return {
        "root": str(root),
        "files": files,
        "folders": folders,
        "errors": errors,
        "cancelled": False,
        "total_files": len(files),
        "total_folders": len(folders),
        "total_size_bytes": sum(item["size_bytes"] for item in files),
        "hidden_files": sum(1 for item in files if item["hidden"]),
    }

def sha256_file(path: str | Path, chunk_size: int = 1024 * 1024) -> str:
    """Read a file only when the user explicitly requests hashing."""
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()

def export_json(data: dict, destination: str | Path) -> None:
    with open(destination, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False)

def export_csv(rows: list[dict], destination: str | Path) -> None:
    if not rows:
        raise ValueError("There are no rows to export.")
    keys = list(rows[0].keys())
    with open(destination, "w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
