from __future__ import annotations

import os
import platform
import shutil
import subprocess
import json
from pathlib import Path

def _run(command: list[str], timeout: int = 12) -> str:
    try:
        result = subprocess.run(
            command, capture_output=True, text=True, timeout=timeout,
            check=False, errors="replace"
        )
        return result.stdout
    except (OSError, subprocess.TimeoutExpired):
        return ""

def get_installed_software() -> list[dict]:
    """Best-effort inventory; sources differ by operating system."""
    system = platform.system().lower()
    rows: list[dict] = []

    if system == "linux":
        if shutil.which("dpkg-query"):
            output = _run(["dpkg-query", "-W", "-f=${binary:Package}\\t${Version}\\n"])
            for line in output.splitlines():
                parts = line.split("\t", 1)
                if len(parts) == 2:
                    rows.append({"name": parts[0], "version": parts[1], "source": "dpkg"})
        elif shutil.which("pacman"):
            output = _run(["pacman", "-Q"])
            for line in output.splitlines():
                parts = line.split(None, 1)
                if len(parts) == 2:
                    rows.append({"name": parts[0], "version": parts[1], "source": "pacman"})
        elif shutil.which("rpm"):
            output = _run(["rpm", "-qa", "--qf", "%{NAME}\\t%{VERSION}-%{RELEASE}\\n"])
            for line in output.splitlines():
                parts = line.split("\t", 1)
                if len(parts) == 2:
                    rows.append({"name": parts[0], "version": parts[1], "source": "rpm"})

    elif system == "windows":
        # Registry uninstall keys are queried through PowerShell; no changes are made.
        script = r"""
        $paths = @(
          'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
          'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
          'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*'
        )
        Get-ItemProperty $paths -ErrorAction SilentlyContinue |
          Where-Object { $_.DisplayName } |
          Select-Object DisplayName, DisplayVersion |
          ConvertTo-Json -Depth 2
        """
        output = _run(["powershell", "-NoProfile", "-Command", script], timeout=20)
        try:
            data = json.loads(output) if output.strip() else []
            if isinstance(data, dict):
                data = [data]
            for item in data:
                rows.append({
                    "name": str(item.get("DisplayName", "")),
                    "version": str(item.get("DisplayVersion", "")),
                    "source": "Windows registry",
                })
        except json.JSONDecodeError:
            pass

    elif system == "darwin":
        apps_dir = Path("/Applications")
        if apps_dir.exists():
            for app in apps_dir.glob("*.app"):
                rows.append({"name": app.stem, "version": "", "source": "/Applications"})
        if shutil.which("brew"):
            output = _run(["brew", "list", "--versions"], timeout=20)
            for line in output.splitlines():
                parts = line.split(None, 1)
                if parts:
                    rows.append({
                        "name": parts[0],
                        "version": parts[1] if len(parts) > 1 else "",
                        "source": "Homebrew",
                    })

    # De-duplicate while preserving the first source found.
    unique = {}
    for row in rows:
        key = (row["name"].casefold(), row["version"])
        unique[key] = row
    return sorted(unique.values(), key=lambda row: row["name"].casefold())
