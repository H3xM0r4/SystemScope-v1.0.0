# Support

For help using SystemScope:

1. Read the installation and troubleshooting sections in [README.md](README.md).
2. Search existing GitHub issues.
3. If you still need help, open a question using GitHub Discussions (if enabled) or create an issue with the **question** label.

When asking for help, include your operating system, Python version, the exact command you ran, and the complete error message. Remove usernames, private paths, tokens, and other personal information first.
