# Screenshot guide

Add genuine screenshots captured from the running application to this folder. Do not use mockups as proof of working features.

Recommended captures for the README:

1. `dashboard.png` — full dashboard with live metric cards and trend graphs.
2. `storage-insights.png` — storage overview after scanning a small test folder.
3. `file-explorer.png` — file metadata table with a non-sensitive test directory.
4. `software-inventory.png` — installed software list with personal details hidden.

Before committing screenshots, inspect them for usernames, home-directory paths, mounted volume names, device identifiers, open windows, and other private information. Blur or crop anything sensitive.
