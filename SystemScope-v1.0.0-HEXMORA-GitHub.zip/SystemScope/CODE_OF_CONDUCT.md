# Code of Conduct

## Our commitment

We want participation in SystemScope to be respectful, constructive, and welcoming to people of all experience levels.

## Expected behavior

- Be respectful and considerate.
- Give actionable, kind feedback.
- Welcome beginner questions and different viewpoints.
- Focus on what is best for the project and its users.
- Respect privacy and never publish another person's sensitive information.

## Unacceptable behavior

Harassment, discrimination, personal attacks, threats, doxxing, and publishing private information without permission are not acceptable.

## Enforcement

Project maintainers may edit or remove contributions that violate this code and may restrict participation when necessary. To report a conduct concern, use GitHub's private contact/reporting options for the repository rather than posting sensitive details publicly.
