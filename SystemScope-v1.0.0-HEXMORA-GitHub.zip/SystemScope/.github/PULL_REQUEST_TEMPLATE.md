## Summary

Describe what changed and why.

## Type of change

- [ ] Bug fix
- [ ] Feature
- [ ] Documentation
- [ ] Refactor / maintenance

## Verification

- [ ] `python -m unittest discover -s tests -v`
- [ ] `python -m compileall -q main.py core ui tests`
- [ ] GUI manually tested (if applicable)

## Safety and privacy

- [ ] No unintended file modifications, deletion, telemetry, or uploads were introduced.
- [ ] No secrets or private scan data are included.

## Screenshots (for UI changes)

Add before/after screenshots where useful.
