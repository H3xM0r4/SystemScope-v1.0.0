# Contributing to SystemScope

Thank you for considering a contribution to SystemScope. Contributions should keep the project safe, understandable, and useful across supported operating systems.

## Before you start

1. Search existing issues to avoid duplicate reports.
2. For a significant change, open an issue first to discuss the approach.
3. Never include passwords, access tokens, private file paths, personal data, or real scan exports in an issue or pull request.

## Development setup

```bash
python3 -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## Quality checks

Run before submitting:

```bash
python -m unittest discover -s tests -v
python -m compileall -q main.py core ui tests
```

For UI changes, launch the app and describe which operating system and desktop environment you tested.

## Contribution guidelines

- Keep scanning read-only. Do not add automatic deletion, modification, cleanup, or upload behavior.
- Do not require root/Administrator privileges for normal operation.
- Do not read file contents during metadata-only scans.
- Keep symlink handling safe and predictable.
- Handle missing metrics and permission errors gracefully.
- Avoid adding dependencies unless they provide clear value.
- Keep user-facing explanations beginner-friendly.
- Update the README and tests when behavior changes.

## Pull request checklist

- [ ] The change has a clear purpose and limited scope.
- [ ] Relevant tests were added or updated.
- [ ] Unit tests pass locally.
- [ ] Python syntax checks pass.
- [ ] GUI changes were manually tested, or the PR explains why they were not.
- [ ] Documentation is updated.
- [ ] No secrets, generated builds, virtual environments, or private scan reports are included.

By submitting a contribution, you agree that your contribution is provided under the project's MIT License.
